$(function(){
    // equivalente ao load de nossa página
});